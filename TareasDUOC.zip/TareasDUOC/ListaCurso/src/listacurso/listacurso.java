package ListaCurso;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class listacurso {

    static Scanner sc = new Scanner(System.in);
    static ArrayList<String> estudiantes = new ArrayList<>();

    static boolean nombreValido(String nombre) {
        if (nombre.isEmpty()) {
            System.out.println("El nombre no puede estar vacio");
            return false;
        }
        if (estudiantes.contains(nombre)) {
            System.out.println("Ese nombre ya esta registrado");
            return false;
        }
        return true;
    }

    static void mostrarLista() {
        if (estudiantes.isEmpty()) {
            System.out.println("La lista esta vacia");
            return;
        }
        for (int i = 0; i < estudiantes.size(); i++) {
            System.out.println((i + 1) + ". " + estudiantes.get(i));
        }
    }

    static int leerNumero() {
        try {
            return Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public static void main(String[] args) {

        int cantidad;
        do {
            System.out.print("Cuantos estudiantes se registraran? ");
            cantidad = leerNumero();
            if (cantidad <= 0) {
                System.out.println("Escribe un numero mayor a 0");
            }
        } while (cantidad <= 0);

        while (estudiantes.size() < cantidad) {
            System.out.print("Nombre del estudiante " + (estudiantes.size() + 1) + ": ");
            String nombre = sc.nextLine().trim();
            if (nombreValido(nombre)) {
                estudiantes.add(nombre);
            }
        }

        int opcion;
        do {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Agregar");
            System.out.println("2. Eliminar");
            System.out.println("3. Buscar");
            System.out.println("4. Mostrar");
            System.out.println("5. Insertar en una posicion");
            System.out.println("6. Reemplazar");
            System.out.println("7. Ordenar");
            System.out.println("8. Vaciar lista");
            System.out.println("9. Salir");
            System.out.print("Elige una opcion: ");
            opcion = leerNumero();

            switch (opcion) {
                case 1:
                    System.out.print("Nombre: ");
                    String nuevo = sc.nextLine().trim();
                    if (nombreValido(nuevo)) {
                        estudiantes.add(nuevo);
                        System.out.println("Estudiante agregado");
                    }
                    break;

                case 2: 
                    mostrarLista();
                    System.out.print("Nombre a eliminar: ");
                    String eliminar = sc.nextLine().trim();
                    if (estudiantes.contains(eliminar)) {
                        estudiantes.remove(eliminar);
                        System.out.println("Estudiante eliminado");
                    } else {
                        System.out.println("Ese nombre no existe en la lista");
                    }
                    break;

                case 3: 
                    System.out.print("Nombre a buscar: ");
                    String buscar = sc.nextLine().trim();
                    int pos = estudiantes.indexOf(buscar);
                    if (pos != -1) {
                        System.out.println(buscar + " esta registrado (posicion " + (pos + 1) + ")");
                    } else {
                        System.out.println(buscar + " no esta registrado");
                    }
                    break;

                case 4:
                    mostrarLista();
                    break;

                case 5: 
                    System.out.print("Nombre: ");
                    String insertar = sc.nextLine().trim();
                    if (nombreValido(insertar)) {
                        System.out.print("En que posicion (1 a " + (estudiantes.size() + 1) + ")? ");
                        int p = leerNumero();
                        if (p >= 1 && p <= estudiantes.size() + 1) {
                            estudiantes.add(p - 1, insertar);
                            System.out.println("Estudiante insertado");
                        } else {
                            System.out.println("Posicion no valida");
                        }
                    }
                    break;

                case 6:
                    mostrarLista();
                    if (!estudiantes.isEmpty()) {
                        System.out.print("Numero del estudiante a reemplazar: ");
                        int r = leerNumero();
                        if (r >= 1 && r <= estudiantes.size()) {
                            System.out.print("Nombre nuevo: ");
                            String reemplazo = sc.nextLine().trim();
                            if (nombreValido(reemplazo)) {
                                estudiantes.set(r - 1, reemplazo);
                                System.out.println("Estudiante reemplazado");
                            }
                        } else {
                            System.out.println("Numero no valido");
                        }
                    }
                    break;

                case 7: 
                    Collections.sort(estudiantes);
                    System.out.println("Lista ordenada");
                    mostrarLista();
                    break;

                case 8: 
                    estudiantes.clear();
                    System.out.println("Lista vaciada");
                    break;

                case 9:
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opcion no valida");
            }
        } while (opcion != 9);

        System.out.println("\nLista final:");
        mostrarLista();
        System.out.println("Estudiantes restantes: " + estudiantes.size());
    }
}