package zoosantiago;

/**
 *
 * @author AL-Alumno
 */
public class ZooSantiago {

    public static void main(String[] args) {
        // Se actualizaron los datos de los perros
        Perro perro1 = new Perro("Rocky", 5, "Golden Retriever");
        Perro perro2 = new Perro("Max", 3, "Beagle");

        // Se actualizaron los datos de los gatos
        Gato gato1 = new Gato("Siames", "Mishifu", 1);
        Gato gato2 = new Gato("Persa", "Pelusa", 4);

        // Se actualizaron los datos de los patos
        Pato pato1 = new Pato("Lucas", 3, "Verde");
        Pato pato2 = new Pato("Margarita", 1, "Amarillo");

        System.out.println("====informacion de los animales====");
        perro1.mostrarInformacion();
        perro2.mostrarInformacion();
        System.out.println();

        gato1.mostrarInformacion();
        gato2.mostrarInformacion();
        System.out.println();

        pato1.mostrarInformacion();
        pato2.mostrarInformacion();
        System.out.println();

        System.out.println("===sonido de animales===");
        System.out.print("El perro " + perro1.getNombre() + " hace:");
        perro1.hacerSonido();
        System.out.print("El perro " + perro2.getNombre() + " hace:");
        perro2.hacerSonido();

        System.out.print("El gato " + gato1.getNombre() + " hace:");
        gato1.hacerSonido();
        System.out.print("El gato " + gato2.getNombre() + " hace:");
        gato2.hacerSonido();

        System.out.print("El pato " + pato1.getNombre() + " hace:");
        pato1.hacerSonido();
        System.out.print("El pato " + pato2.getNombre() + " hace:");
        pato2.hacerSonido();
    }
}
